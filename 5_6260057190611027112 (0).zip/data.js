module.exports = {

    mongoLink:'',//database link
    
    bot_token:'1956917944:AAHQdSXqyGKFnbf4FbO9IBAoKDca6kSUVn0',//bot token
    
    bot_name:'New1trybot',//bot username without @
    
    bot_admin:65555,// admin telegram id
    
    channelsList : ['@FortniteAirdrop'],// channels list
    
    reffer_bonus:1000,// refferal bonus amount
    
    min_wd:2000,//min withdrawal amount
    
    daily_bonus:0.001,// daily bonus amount
    
    currency:'', //bot cuurency
    
    cb_api_key:'',//coinbase api key
    
    cb_api_secret:'',// coinbase secret key
    
    cb_account_id:'',// counbase account id for the bot currency
    
    payment_channel:'@payoutproof12'// payment channel username
    
    }
